export const MEMOS_VIEW_TYPE = "memos_view";
export const VIEW_TYPE = "react-view";
