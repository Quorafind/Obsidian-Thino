// import React from "react";
// import Home from "../pages/Home";

// const appRouter = {
//   "*": <Home />,
// };

// export default appRouter;
