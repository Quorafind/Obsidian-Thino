# Services

What should service do?

- request data api and throw error;
- dispatch state actions;
