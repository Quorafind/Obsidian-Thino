export const TRANSLATIONS_ZH = {
    welcome: "欢迎使用 Memos ",
    ribbonIconTitle: "Memos",
    months: ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"],
    weekDays: ["周日", "周一", "周二", "周三", "周四", "周五", "周六"],
    weekDaysShort: ["周日", "周一", "周二", "周三", "周四", "周五", "周六"],
    to: "至",
  };