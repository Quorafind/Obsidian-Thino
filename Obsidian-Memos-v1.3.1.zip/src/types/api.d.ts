declare namespace Api {
  interface MemosStat {
    timestamp: string;
    amount: number;
  }
}
