type MemoSpecType = "NOT_TAGGED" | "LINKED" | "IMAGED" | "CONNECTED";
